package com.sbcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDay3CrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDay3CrudApplication.class, args);
	}

}
