package com.sbcrud.servicei;

import com.sbcrud.model.Student;

public interface ServiceI {

	public void saveStudent(Student s);
	
	public Iterable<Student> getAllStudents();
	
	public Student editStudent(int id);
	
	public void deleteStudent(Student s);
	

}
